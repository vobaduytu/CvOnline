class Experience {
    constructor(id, time, nameCompany, position, experience, idPerson) {
        this.id = id;
        this.time = time;
        this.nameCompany = nameCompany;
        this.position = position;
        this.experience = experience;
        this.idPerson = idPerson;
    }
}