class Skill {
    constructor(id, name, levelScore, idPerson) {
        this.id = id;
        this.name = name;
        this.levelScore = levelScore;
        this.idPerson = idPerson;
    }
}