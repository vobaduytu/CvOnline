class Project {
    constructor(id, name, image1, image2, linkDetail, idPerson) {
        this.id = id;
        this.name = name;
        this.image1 = image1;
        this.image2 = image2;
        this.linkDetail = linkDetail;
        this.idPerson = idPerson;
    }
}