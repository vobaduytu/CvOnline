class Person {
    constructor(id, avatar, name, gender, level, dob, contacts, gitHub, interests, character, shortTarget, longTarget, skills, educations, experiences, projects, certificates, referencePersons, introduce) {
        this.id = id;
        this.avatar = avatar;
        this.name = name;
        this.gender = gender;
        this.level = level;
        this.dob = dob;
        this.contacts = contacts;
        this.gitHub = gitHub;
        this.interests = interests;
        this.shortTarget = shortTarget;
        this.longTarget = longTarget;
        this.skills = skills;
        this.educations = educations;
        this.experiences = experiences;
        this.projects = projects;
        this.certificates = certificates;
        this.referencePersons = referencePersons;
        this.introduce = introduce;
        this.character = character;
    }
}