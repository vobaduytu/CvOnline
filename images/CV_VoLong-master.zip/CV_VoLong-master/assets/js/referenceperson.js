class ReferencePerson {
    constructor(id, name, avt, position, company, phone, email, idPerson) {
        this.id = id;
        this.name = name;
        this.avt = avt;
        this.position = position;
        this.company = company;
        this.phone = phone;
        this.email = email;
        this.idPerson = idPerson;
    }
}