class Education {
    constructor(id, time, nameSchool, course, result, idPerson) {
        this.id = id;
        this.time = time;
        this.nameSchool = nameSchool;
        this.course = course;
        this.result = result;
        this.idPerson = idPerson;
    }
}