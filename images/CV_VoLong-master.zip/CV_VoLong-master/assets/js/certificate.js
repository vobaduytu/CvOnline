class Certificate {
    constructor(id, name, time, uses, linkImg, icon, idPerson) {
        this.id = id;
        this.name = name;
        this.time = time;
        this.uses = uses;
        this.linkImg = linkImg;
        this.icon = icon;
        this.idPerson = idPerson;
    }
}