class Contacts {
    constructor(id, phone, email, address, iframe, idPerson) {
        this.id = id;
        this.phone = phone;
        this.email = email;
        this.address = address;
        this.iframe = iframe;
        this.idPerson = idPerson;
    }
}